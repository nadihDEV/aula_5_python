fila = []

while True:
    cliente = input("Digite o nome do cliente (ou fim para sair): ")

    if cliente == 'fim':
        break
    fila.append(cliente)
    print(f"Cliente: {cliente} adicionado à fila.")

print(fila)

#Estrutura para atender a fila 
while fila:
    atendido = fila.pop(0)
    print(f"Cliene {atendido} atendido!")