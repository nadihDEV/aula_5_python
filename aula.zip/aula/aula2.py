import os

lista_alta = []
lista_baixa = []

while True:
    opcao = input("1. Adicionar documentos, 2. Imprimir documentos, 3. Sair: ")

    if opcao == '1':
        tipo = input("insira tipo de documento: ")
        prioridade = input("insira a prioridade Alta ou Baixa: ")
        os.system('cls')

        if prioridade == 'alta':
            lista_alta.append(tipo)
        
        else:
            lista_baixa.append(tipo)

    elif opcao == '2':
        if lista_alta:
            print(f"Imprimindo: {lista_alta.pop(0)} - Alta prioridade") 
        elif lista_baixa:
            print(f"Imprimindo: {lista_baixa.pop(0)} - Baixa prioridade")
        else:
            print("Não existe documentos")       

    elif opcao == '3':
        break

print(lista_alta)
print(lista_baixa)