pilha = []

while True:
    produto = input("digite o nome do produto (Ou fim para sair):")

    if produto == 'fim':
        break
    pilha.append(produto)
    print(f"Produto: {produto}")

while pilha:
    retira = pilha.pop()
    print(f'{retira}')