import os
os.system("cls")

pilha1 = []
pilha2 = []
pilha3 = []
pilha4 = []
pilha5 = []

while True:
    cliente = input("Digite o nome do cliente: ")
    if cliente == 'sair':
        os.system("cls")
        break
    prioridade =  int(input("Digite o nivel de prioridade (1 - menos urgente a 5 - mais urgente)"))
    if prioridade == 1: 
        pilha1.append(cliente)
        print(f"{cliente} add na pilha.")
    elif prioridade == 2:
        pilha2.append(cliente)
        print(f"{cliente} add na pilha.")
    elif prioridade == 3:
        pilha3.append(cliente)
        print(f"{cliente} add na pilha.")
    elif prioridade == 4:
        pilha4.append(cliente)
        print(f"{cliente} add na pilha.")
    elif prioridade == 5:
        pilha5.append(cliente)
        print(f"{cliente} add na pilha.")

while pilha5:
    cliente = pilha5.pop(0)
    print(f"Urgencia 5: {cliente} retirado da pilha.")

while pilha4:
    cliente = pilha4.pop(0)
    print(f"Urgencia 4: {cliente} retirado da pilha.")

while pilha3:
    cliente = pilha3.pop(0)
    print(f"Urgencia 3: {cliente} retirado da pilha.")

while pilha2:
    cliente = pilha2.pop(0)
    print(f"Urgencia 2: {cliente} retirado da pilha.")

while pilha1:
    cliente = pilha1.pop(0)
    print(f"Urgencia 1: {cliente} retirado da pilha.")
